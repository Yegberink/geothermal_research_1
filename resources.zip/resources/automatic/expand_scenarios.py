from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Tuple
import pandas as pd
import numpy as np


def _parse_bool(x: Any) -> Any:
    if isinstance(x, bool):
        return x
    if isinstance(x, str):
        s = x.strip().lower()
        if s in {"true", "t", "1", "yes", "y"}:
            return True
        if s in {"false", "f", "0", "no", "n"}:
            return False
    return x


def _format_delta_tag(delta: float) -> str:
    # delta is fraction (e.g., -0.125 -> -12.5)
    pct = delta * 100.0

    # If it's basically an integer, keep it as an int
    if abs(pct - round(pct)) < 1e-9:
        pct_str = str(int(round(pct)))
    else:
        # Keep a compact decimal, then replace "." with "_" for filenames
        pct_str = f"{pct:.6g}".rstrip("0").rstrip(".").replace(".", "_")

    if pct < 0:
        return f"m{pct_str}"  # minus
    return f"p{pct_str}"      # plus



def _make_unique(existing: set[str], name: str) -> str:
    if name not in existing:
        return name
    i = 2
    while f"{name}_{i}" in existing:
        i += 1
    return f"{name}_{i}"


def _coerce_types(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()

    # Booleans
    if "include_egs" in df.columns:
        df["include_egs"] = df["include_egs"].map(_parse_bool)

    # Try to convert numerics where possible (leave strings alone)
    for c in df.columns:
        if c == "scenario":
            continue
        # don't coerce obvious categorical columns
        if c in {"carrier_out", "SED_NAN_POLICY"}:
            continue
        df[c] = pd.to_numeric(df[c], errors="ignore")

    return df


def generate_single_parameter_scenarios(
    tsv_in: str | Path,
    tsv_out: str | Path,
    *,
    base_scenario: str = "base",
    max_dev_pct: float = 20.0,   # NEW: e.g. 50.0 -> ±50%
    steps: int = 2,              # NEW: number of steps on ONE side (2 -> 4 scenarios, 4 -> 8 scenarios)
    deltas: List[float] | None = None,  # optional override (fractions)
) -> pd.DataFrame:
    """
    Generates scenarios by changing ONLY ONE parameter at a time.

    Numeric params: scaled by (1 + delta) for delta in deltas, within ±pct_range.
    Categorical params:
      - include_egs -> ensure both True and False exist (single change)
      - SED_NAN_POLICY -> ensure both always_egs and depth_only exist (single change)
    carrier_out is forced to 'power' for all scenarios (not treated as a scenario dimension).
    """
    df = pd.read_csv(tsv_in, sep="\t")
    if "scenario" not in df.columns:
        raise ValueError("Expected a 'scenario' column in the TSV.")

    df = _coerce_types(df)

    if (df["scenario"] == base_scenario).sum() != 1:
        raise ValueError(f"Base scenario '{base_scenario}' must match exactly one row.")

    base_row = df.loc[df["scenario"] == base_scenario].iloc[0].copy()

    # Force carrier_out to power in base + all generated scenarios
    if "carrier_out" in df.columns:
        df.loc[:, "carrier_out"] = "power"
        base_row["carrier_out"] = "power"

    existing_names = set(df["scenario"].astype(str).tolist())
    new_rows: List[pd.Series] = []

    # Choose deltas (fractional), trimmed to range and max count
    # Choose deltas (fractional)
    if deltas is None:
        if steps < 1:
            raise ValueError("steps must be >= 1")

        pct_range = max_dev_pct / 100.0
        step = pct_range / steps

        # steps=4, max_dev_pct=50 -> [-0.5,-0.375,-0.25,-0.125, +0.125,+0.25,+0.375,+0.5]
        neg = [-(k * step) for k in range(steps, 0, -1)]
        pos = [(k * step) for k in range(1, steps + 1)]
        deltas = neg + pos
    else:
        # ensure non-zero
        deltas = [d for d in deltas if abs(d) > 1e-12]


    # ensure within range and non-zero
    deltas = [d for d in deltas if abs(d) <= pct_range and abs(d) > 1e-12]

    # Identify numeric columns (excluding scenario and known categoricals)
    categorical_cols = {"scenario", "carrier_out", "SED_NAN_POLICY"}
    bool_cols = {"include_egs"}
    numeric_cols = []
    for c in df.columns:
        if c in categorical_cols or c in bool_cols:
            continue
        # numeric if base_row[c] is int/float (numpy ok) and not boolean
        v = base_row[c]
        if isinstance(v, (int, float, np.integer, np.floating)) and not isinstance(v, bool):
            numeric_cols.append(c)

    # 1) Numeric single-parameter scenarios (±20%)
    for col in numeric_cols:
        v0 = base_row[col]
        # If v0 is 0, % changes are all 0 — skip (or implement absolute deltas if you want)
        if float(v0) == 0.0:
            continue

        for d in deltas:
            v_new = float(v0) * (1.0 + d)
            tag = _format_delta_tag(d)
            name_base = f"{base_scenario}_{col}{tag}"
            name = _make_unique(existing_names, name_base)

            r = base_row.copy()
            r["scenario"] = name
            r[col] = v_new
            # enforce carrier_out again just in case
            if "carrier_out" in r.index:
                r["carrier_out"] = "power"

            new_rows.append(r)
            existing_names.add(name)

    # 2) include_egs scenarios (single-parameter)
    if "include_egs" in df.columns:
        for target in [True, False]:
            if base_row["include_egs"] != target:
                name_base = f"{base_scenario}_include_egs{str(target)}"
                name = _make_unique(existing_names, name_base)
                r = base_row.copy()
                r["scenario"] = name
                r["include_egs"] = target
                if "carrier_out" in r.index:
                    r["carrier_out"] = "power"
                new_rows.append(r)
                existing_names.add(name)

    # 3) SED_NAN_POLICY scenarios (single-parameter)
    if "SED_NAN_POLICY" in df.columns:
        allowed = ["always_egs", "depth_only"]
        for target in allowed:
            if str(base_row["SED_NAN_POLICY"]) != target:
                name_base = f"{base_scenario}_SED_NAN_POLICY_{target}"
                name = _make_unique(existing_names, name_base)
                r = base_row.copy()
                r["scenario"] = name
                r["SED_NAN_POLICY"] = target
                if "carrier_out" in r.index:
                    r["carrier_out"] = "power"
                new_rows.append(r)
                existing_names.add(name)

    # Append and write
    if new_rows:
        df_out = pd.concat([df, pd.DataFrame(new_rows)], ignore_index=True)
    else:
        df_out = df.copy()

    # Optional: sort for readability
    df_out = df_out.sort_values("scenario").reset_index(drop=True)

    Path(tsv_out).parent.mkdir(parents=True, exist_ok=True)
    df_out.to_csv(tsv_out, sep="\t", index=False)

    return df_out


if __name__ == "__main__":
    df_out = generate_single_parameter_scenarios(
        "resources/automatic/scenario_table.tsv",
        "resources/automatic/scenario_table_expanded.tsv",
        base_scenario="base",
        max_dev_pct=50.0,  # <- set your max deviation (%)
        steps=5,           # <- number of steps on one side (4 => 8 scenarios total)
        deltas=None,       # optional override; leave None to use max_dev_pct/steps grid
    )
    print(f"Wrote {len(df_out)} rows to scenario_table_auto.tsv")
